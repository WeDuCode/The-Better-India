const mongoose = require('mongoose');
const Article = require('./models/Article'); // path to your model
require('dotenv').config();

const dummyArticles = [
  {
    title: 'Innovative Farming in Punjab',
    content: 'Farmers are adopting solar irrigation methods...',
    category: 'Stories',
    tags: ['Innovation', 'Sustainability'],
    date: new Date('2024-01-15'),
  },
  {
    title: 'Green Schools Program Launch',
    content: 'A new initiative promotes eco-education in schools...',
    category: 'News',
    tags: ['Education', 'Sustainability'],
    date: new Date('2024-02-10'),
  },
  {
    title: 'Women Empowerment Event in Delhi',
    content: 'Event highlights women-led startups and initiatives...',
    category: 'Events',
    tags: ['Innovation', 'Education'],
    date: new Date('2024-03-05'),
  }
];

mongoose.connect(process.env.MONGO_URI)
  .then(async () => {
    console.log('MongoDB connected!');
    await Article.deleteMany(); // optional: clear old data
    await Article.insertMany(dummyArticles);
    console.log('Dummy data inserted!');
    mongoose.disconnect();
  })
  .catch(err => console.error('Error:', err));
