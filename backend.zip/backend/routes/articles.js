const express = require('express');
const router = express.Router();
const Article = require('../models/Article');

// GET /api/articles/search
router.get('/search', async (req, res) => {
  try {
    const { searchTerm, category, tags, startDate, endDate } = req.query;

    const query = {};

    if (searchTerm) {
      query.title = { $regex: searchTerm, $options: 'i' };
    }

    if (category && category !== 'All') {
      query.category = category;
    }

    if (tags) {
      const tagArray = Array.isArray(tags) ? tags : [tags];
      query.tags = { $in: tagArray };
    }

    if (startDate && endDate) {
      query.date = {
        $gte: new Date(startDate),
        $lte: new Date(endDate),
      };
    }

    const results = await Article.find(query).sort({ date: -1 });
    res.json(results);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error' });
  }
});

module.exports = router;
