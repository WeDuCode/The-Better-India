const mongoose = require('mongoose');

const ArticleSchema = new mongoose.Schema({
  title: String,
  content: String,
  category: String, // e.g., 'Stories', 'Events'
  tags: [String],   // e.g., ['Sustainability', 'Innovation']
  date: Date        // e.g., '2023-04-10'
});

module.exports = mongoose.model('Article', ArticleSchema);
