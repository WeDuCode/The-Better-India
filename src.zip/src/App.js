import React from 'react';
import SearchPage from './pages/SearchPage';

function App() {
  return (
    <div className="App">
      <SearchPage />
    </div>
  );
}

export default App;