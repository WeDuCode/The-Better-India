// SearchPage.js

import React, { useState } from 'react';
import './SearchPage.css';

const SearchPage = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [category, setCategory] = useState('Events');
  const [tags, setTags] = useState([]);
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');

  const handleTagChange = (tag) => {
    setTags((prevTags) =>
      prevTags.includes(tag)
        ? prevTags.filter((t) => t !== tag)
        : [...prevTags, tag]
    );
  };

  const handleSearch = () => {
    console.log({ searchTerm, category, tags, startDate, endDate });
    // Add search logic here
  };

  return (
    <div className="search-page">
      <div className="search-container">
        <h1 className="search-heading">The Better India – Article Search</h1>
        <div className="form-section">
          <input
            type="text"
            placeholder="Search..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
          <select
            value={category}
            onChange={(e) => setCategory(e.target.value)}
          >
            <option value="Events">Events</option>
            <option value="Stories">Stories</option>
          </select>
        </div>

        {/* Tags Section */}
        <div className="form-section tags-section">
          <label className="tags-heading">Tags:</label>
          <div className="tag-items">
            {['Sustainability', 'Innovation', 'Education'].map((tag) => (
              <label key={tag} className="tag-item">
                <input
                  type="checkbox"
                  checked={tags.includes(tag)}
                  onChange={() => handleTagChange(tag)}
                />
                <strong>{tag}</strong>
              </label>
            ))}
          </div>
        </div>

        {/* Date Range Section */}
        <div className="form-section date-section">
          <label className="tags-heading">Date Range:</label>
          <div className="date-range">
            <div className="date-input">
              <label className="section-label">Start Date:</label>
              <input
                type="date"
                value={startDate}
                onChange={(e) => setStartDate(e.target.value)}
              />
            </div>
            <div className="date-input">
              <label className="section-label">End Date:</label>
              <input
                type="date"
                value={endDate}
                onChange={(e) => setEndDate(e.target.value)}
              />
            </div>
          </div>
        </div>

        <button onClick={handleSearch}>Search</button>
      </div>
    </div>
  );
};

export default SearchPage;
