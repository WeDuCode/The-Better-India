import React, { useState } from 'react';
import _ from 'lodash';

const SearchBar = ({ onChange }) => {
  const [input, setInput] = useState('');

  const debouncedChange = _.debounce(onChange, 500);

  const handleChange = (e) => {
    setInput(e.target.value);
    debouncedChange(e.target.value);
  };

  return <input type="text" placeholder="Search..." value={input} onChange={handleChange} />;
};

export default SearchBar;
