 import React from 'react';

const ResultsList = ({ results }) => (
  <div>
    {results.map((item) => (
      <div key={item._id}>
        <h3>{item.title}</h3>
        <p>{item.content.slice(0, 100)}...</p>
        <p><strong>Category:</strong> {item.category} | <strong>Date:</strong> {new Date(item.date).toLocaleDateString()}</p>
        <p><strong>Tags:</strong> {item.tags.join(', ')}</p>
      </div>
    ))}
  </div>
);

export default ResultsList;
