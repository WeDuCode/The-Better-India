import React from 'react';

const FilterPanel = ({ category, setCategory, tags, setTags, dateRange, setDateRange }) => {
  const handleTagChange = (e) => {
    const tag = e.target.value;
    setTags((prev) =>
      prev.includes(tag) ? prev.filter((t) => t !== tag) : [...prev, tag]
    );
  };

  return (
    <div>
      <select value={category} onChange={(e) => setCategory(e.target.value)}>
        <option value="">All Categories</option>
        <option value="Stories">Stories</option>
        <option value="News">News</option>
        <option value="Events">Events</option>
      </select>

      <div>
        Tags:
        {['Sustainability', 'Innovation', 'Education'].map((tag) => (
          <label key={tag}>
            <input
              type="checkbox"
              value={tag}
              checked={tags.includes(tag)}
              onChange={handleTagChange}
            />
            {tag}
          </label>
        ))}
      </div>

      <div>
        Date Range:
        <input type="date" value={dateRange.start} onChange={(e) => setDateRange((prev) => ({ ...prev, start: e.target.value }))} />
        <input type="date" value={dateRange.end} onChange={(e) => setDateRange((prev) => ({ ...prev, end: e.target.value }))} />
      </div>
    </div>
  );
};

export default FilterPanel;
