import React from 'react';

const PaginationControls = ({ page, setPage, totalPages }) => (
  <div>
    <button onClick={() => setPage((p) => Math.max(p - 1, 1))} disabled={page === 1}>Previous</button>
    <span> Page {page} of {totalPages} </span>
    <button onClick={() => setPage((p) => Math.min(p + 1, totalPages))} disabled={page === totalPages}>Next</button>
  </div>
);

export default PaginationControls;
